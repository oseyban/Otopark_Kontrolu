package com.os.kotlin_harita

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class ReservasyonActivity : AppCompatActivity() {

    private lateinit var spinner: Spinner
    private lateinit var editTextAdSoyad: EditText
    private lateinit var editTextSuresi: EditText
    private lateinit var spinnerBaslangicSaat: Spinner
    private lateinit var spinnerBitisSaat: Spinner
    private lateinit var buttonReservasyonYap: Button
    private lateinit var buttonUcretOde: Button
    private lateinit var textViewReservasyonTarihi: TextView

    private var selectedDate = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reservasyon)

        initializeViews()
        setupFirestore()
        setupListeners()
    }

    private fun initializeViews() {
        spinner = findViewById(R.id.spinner)
        editTextAdSoyad = findViewById(R.id.editTextAdSoyad)
        editTextSuresi = findViewById(R.id.editTextSuresi)
        spinnerBaslangicSaat = findViewById(R.id.spinnerBaslangicSaat)
        spinnerBitisSaat = findViewById(R.id.spinnerBitisSaat)
        buttonReservasyonYap = findViewById(R.id.buttonReservasyonYap)
        buttonUcretOde = findViewById(R.id.buttonUcretOde)
        textViewReservasyonTarihi = findViewById(R.id.textViewReservasyonTarihi)
    }

    private fun setupFirestore() {
        val db = FirebaseFirestore.getInstance()

        db.collection("users")
            .get()
            .addOnSuccessListener { result ->
                val otoparkList = ArrayList<String>()
                otoparkList.add("Otopark Seçiniz")

                for (document in result) {
                    val otoparkAdi = document.getString("otoparkAdi")
                    if (otoparkAdi != null) {
                        otoparkList.add(otoparkAdi)
                    }
                }

                setupSpinner(spinner, otoparkList)

                val saatler = resources.getStringArray(R.array.saatler)
                val saatler1 = resources.getStringArray(R.array.saatler1)

                setupSpinner(spinnerBaslangicSaat, saatler.toList())
                setupSpinner(spinnerBitisSaat, saatler1.toList())
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Veri getirme hatası: $exception", Toast.LENGTH_SHORT).show()
            }
    }

    private fun setupListeners() {
        val buttonTarihSec: Button = findViewById(R.id.buttonTarihSec)
        buttonTarihSec.setOnClickListener {
            showDatePickerDialog()
        }

        buttonReservasyonYap.setOnClickListener {
            reservasyonuYap()
        }

        buttonUcretOde.setOnClickListener {
            // TODO: Ücret ödeme işlemleri
        }
    }

    private fun setupSpinner(spinner: Spinner, itemList: List<String>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, itemList)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }

    private fun reservasyonuYap() {
        val adSoyad = editTextAdSoyad.text.toString()
        val suresi = editTextSuresi.text.toString().toInt()
        val baslangicSaat = spinnerBaslangicSaat.selectedItem.toString()
        val bitisSaat = spinnerBitisSaat.selectedItem.toString()
        val otoparkAdi = spinner.selectedItem.toString()

        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val rezervasyonTarihiStr = sdf.format(selectedDate.time)

        val currentTime = Calendar.getInstance().timeInMillis

        // Firestore bağlantısı
        val db = FirebaseFirestore.getInstance()

        // Örnek olarak, kullanıcı ID'si "userId" olarak kabul edilmiş olsun
        val userId = "yourUserId" // Set the actual user ID here

        // Kullanıcının en son yaptığı rezervasyonun zamanını Firestore'dan al
        db.collection("reservasyon")
            .whereEqualTo("userId", userId) // Replace with the actual field and value to identify the user
            .orderBy("rezervasyonTarihi", Query.Direction.DESCENDING) // Assuming the latest reservation comes first
            .limit(1)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    // Kullanıcının önceki rezervasyonu yoksa, lastReservationTime'i varsayılan bir değere ayarla
                    val defaultLastReservationTime: Long = 0
                    // Devam eden işlemler...
                } else {
                    // En son rezervasyonun tarihini al
                    val lastReservationTime = documents.first().getLong("rezervasyonTarihi") ?: 0

                    // Kontrolü gerçekleştir
                    if (currentTime - lastReservationTime < TimeUnit.HOURS.toMillis(1)) {
                        // Kullanıcı aynı otopark için bir saat içinde tekrar rezervasyon yapmış
                        Toast.makeText(this, "Lütfen bir saat sonra tekrar rezervasyon yapın.", Toast.LENGTH_SHORT).show()
                        return@addOnSuccessListener
                    }

                    // Devam eden işlemler...
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Rezervasyon zamanını alma hatası: $exception", Toast.LENGTH_SHORT).show()
            }

        val reservasyonBilgileri = hashMapOf(
            "adSoyad" to adSoyad,
            "suresi" to suresi,
            "baslangicSaat" to baslangicSaat,
            "bitisSaat" to bitisSaat,
            "otoparkAdi" to otoparkAdi,
            "rezervasyonTarihi" to rezervasyonTarihiStr
        )

        db.collection("reservasyon")
            .add(reservasyonBilgileri)
            .addOnSuccessListener {
                Toast.makeText(
                    this,
                    "Sayın $adSoyad, $rezervasyonTarihiStr tarihli, başlama saati: $baslangicSaat ile Bitiş Saati: $bitisSaat arasındaki rezervasyonunuz başarıyla gerçekleşmiştir. 15 dakikalık gecikme sonunda rezervasyonunuz otomatik olarak iptal olacaktır.",
                    Toast.LENGTH_LONG
                ).show()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Rezervasyon kaydetme hatası: $exception", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showDatePickerDialog() {
        val datePicker = DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
                selectedDate.set(Calendar.YEAR, year)
                selectedDate.set(Calendar.MONTH, month)
                selectedDate.set(Calendar.DAY_OF_MONTH, dayOfMonth)

                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                textViewReservasyonTarihi.text = sdf.format(selectedDate.time)
            },
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.datePicker.minDate = System.currentTimeMillis() - 1000
        datePicker.show()
    }
}
