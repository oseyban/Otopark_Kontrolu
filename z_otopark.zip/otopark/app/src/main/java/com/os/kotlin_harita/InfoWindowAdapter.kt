package com.os.kotlin_harita

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.Marker

class InfoWindowAdapter(private val context: Context) : GoogleMap.InfoWindowAdapter {

    override fun getInfoWindow(marker: Marker): View? {
        return null
    }

    override fun getInfoContents(marker: Marker): View {
        val contentView = LayoutInflater.from(context).inflate(R.layout.toast_layout, null)

        // Özelleştirmeleri yap

        return contentView
    }
}
