package com.os.kotlin_harita

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
//import com.os.kotlin_harita.R // Sizin uygulamanızın R sınıfı ile değiştirin

class UyelikActivity : AppCompatActivity() {

    private lateinit var uyelikEmailEditText: EditText
    private lateinit var uyelikPasswordEditText: EditText
    private lateinit var uyelikPasswordRepeatEditText: EditText
    private lateinit var uyelikButton: Button

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.uyelik)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        uyelikEmailEditText = findViewById(R.id.uyelikEmailEditText)
        uyelikPasswordEditText = findViewById(R.id.uyelikPasswordEditText)
        uyelikPasswordRepeatEditText = findViewById(R.id.uyelikPasswordRepeatEditText)
        uyelikButton = findViewById(R.id.uyelikButton)

        uyelikButton.setOnClickListener {
            val email = uyelikEmailEditText.text.toString()
            val password = uyelikPasswordEditText.text.toString()
            val passwordRepeat = uyelikPasswordRepeatEditText.text.toString()

            if (email.isEmpty() || password.isEmpty() || passwordRepeat.isEmpty()) {
                Toast.makeText(this, "Lütfen tüm alanları doldurun.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password != passwordRepeat) {
                Toast.makeText(this, "Parolalar eşleşmiyor.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Firebase Authentication ile üyelik oluştur
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Üyelik başarılı!", Toast.LENGTH_SHORT).show()

                        // Firestore'a kullanıcı bilgilerini ekle
                        val userDocument = firestore.collection("users").document(email)
                        val initialData = hashMapOf(
                            "boylam" to "0",
                            "enlem" to "0",
                            "kapasite" to "0",
                            "ucret" to "0",
                            "otoparkAdi" to "otopark-0"
                        )

                        userDocument.set(initialData)
                            .addOnSuccessListener {
                                val intent = Intent(this, OtoparkActivity::class.java)
                                startActivity(intent)
                                finish()
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(this, "Firestore'a veri eklenirken hata oluştu: $e", Toast.LENGTH_SHORT).show()
                            }
                    } else {
                        Toast.makeText(this, "Üyelik oluşturulamadı. Hata: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }
}
