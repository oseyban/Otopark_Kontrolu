package com.os.kotlin_harita

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.*
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task

class OtoparkActivity : Activity() {

    private lateinit var mapImageView: ImageView
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var mapButton: Button
    private lateinit var uyelikButton: Button
    private lateinit var reservasyonButton: Button
    private lateinit var googleSignInButton: SignInButton
    private val RC_SIGN_IN = 9001

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.otopark)

        // XML dosyasındaki bileşenleri tanımla
        mapImageView = findViewById(R.id.mapImageView)
        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        mapButton = findViewById(R.id.mapButton)
        uyelikButton = findViewById(R.id.uyelikButton)
        reservasyonButton = findViewById(R.id.reservasyonButton)
        googleSignInButton = findViewById(R.id.googleSignInButton)

        // GoogleSignInOptions ayarları
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        val googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Giriş yap düğmesine tıklanınca yapılacak işlemi tanımla
        loginButton.setOnClickListener {
            // Kullanıcı adı ve parolayı al
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Kullanıcı adı ve parolayı kontrol et (örneğin, boş olup olmadığını kontrol et)
            if (username.isNotEmpty() && password.isNotEmpty()) {
                // Kullanıcı adı ve parola doğru, Toast mesajı göster
                val message = "Giriş Başarılı. Kullanıcı Adı: $username, Parola: $password"
                Toast.makeText(this@OtoparkActivity, message, Toast.LENGTH_SHORT).show()
                sendEmailToNextActivity(username)
                val intent = Intent(this@OtoparkActivity, OtoparkSahibi::class.java)
                startActivity(intent)
            } else {
                // Kullanıcı adı veya parola eksik, hata mesajı göster
                Toast.makeText(
                    this@OtoparkActivity,
                    "Kullanıcı adı ve parola gerekli",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // Haritaya Tıklayınca
        mapImageView.setOnClickListener {
            val intent = Intent(this@OtoparkActivity, MapsActivity::class.java)
            startActivity(intent)
        }
        // Haritaya Geç Düğmesi
        mapButton.setOnClickListener {
            val intent = Intent(this@OtoparkActivity, MapsActivity::class.java)
            startActivity(intent)
        }

        // Üyelik Düğmesi
        uyelikButton.setOnClickListener {
            val intent = Intent(this@OtoparkActivity, UyelikActivity::class.java)
            startActivity(intent)
        }

        // Google SignIn Düğmesi
        googleSignInButton.setOnClickListener {
            val signInIntent = googleSignInClient.signInIntent
            startActivityForResult(signInIntent, RC_SIGN_IN)
        }
        // Rezervasyon düğmesi
        val reservasyonButton: Button = findViewById(R.id.reservasyonButton)
        reservasyonButton.setOnClickListener {
            // RezervasyonActivity'e geçiş
            val intent = Intent(this@OtoparkActivity, ReservasyonActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Google hesabıyla giriş yapma sonucunu kontrol et
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }

    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)

            // Google hesabıyla giriş başarılı, burada istediğiniz işlemleri yapabilirsiniz
            // Örneğin, kullanıcının adını ve e-posta adresini alabilirsiniz:

            //val userName = account?.displayName
            val email = account?.email
            sendEmailToNextActivity(email)
            val intent = Intent(this@OtoparkActivity, OtoparkSahibi::class.java)
            startActivity(intent)
            // Diğer işlemleri ekleyebilirsiniz

        } catch (e: ApiException) {
            // Google hesabıyla giriş başarısız
            // Hata mesajını loglayabilir veya kullanıcıya bildirebilirsiniz
            e.printStackTrace()
        }
    }

    private fun sendEmailToNextActivity(email: String?) {
        // E-posta adresini diğer sayfaya göndermek için Intent oluştur
        val intent = Intent(this, OtoparkSahibi::class.java)
        intent.putExtra("email", email)
        startActivity(intent)
    }
}
