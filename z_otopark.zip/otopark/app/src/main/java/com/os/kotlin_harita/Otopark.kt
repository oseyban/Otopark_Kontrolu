package com.os.kotlin_harita

data class Otopark(
    val otoparkAdi: String = "",
    val kapasite: String = "",
    val enlem: String = "",
    val boylam: String = "",
    val saatlikUcret: String = ""
)
